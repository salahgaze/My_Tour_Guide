package com.salah.my_tour_guide;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.widget.Toast;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class MainActivity extends AppCompatActivity {

    TabLayout tabLayout;
    ViewPager viewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    // inflate to TabLayout
    tabLayout = (TabLayout) findViewById(R.id.main_tabLayout);
    // inflate to ViewPager
    viewPager = findViewById(R.id.main_pager);

    PagerAdapter adapter = new PagerAdapter(getSupportFragmentManager());
        // to add Tabs
        adapter.addTab(new MyTabs(new Category(1,"Mosque"),MosqueFragment.newInstance(1,"Mosque")));
        adapter.addTab(new MyTabs(new Category(2,"Museum"),MuseumFragment.newInstance(2,"Museum")));
        adapter.addTab(new MyTabs(new Category(3,"Parks"),ParksFragment.newInstance(3,"Parks")));
        adapter.addTab(new MyTabs(new Category(4,"Streets"),StreetsFragment.newInstance(4,"Streets")));

    viewPager.setAdapter(adapter);
    tabLayout.setupWithViewPager(viewPager);

    }
}