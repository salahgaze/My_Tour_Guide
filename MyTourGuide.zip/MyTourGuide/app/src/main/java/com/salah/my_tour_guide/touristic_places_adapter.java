package com.salah.my_tour_guide;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

class touristic_places_adapter extends ArrayAdapter<touristic_places> {

    public touristic_places_adapter(@NonNull Context context, ArrayList<touristic_places> resource) {
        super(context, 0,resource);
    }
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        // Check if the existing view is being reused, otherwise inflate the view
        View listItemview = convertView;

        if (listItemview == null) {
            listItemview = LayoutInflater.from(getContext()).inflate(R.layout.fragment_list, parent, false);
        }

        // Get the Place object located at this position in the list
        touristic_places currentPlace = (touristic_places) getItem(position);
        // Find the TextView in the list_item.xml and set to it the place name from Place object
        TextView placeTextView = listItemview.findViewById(R.id.text_name);
        placeTextView.setText(currentPlace.getName().toString());

        // Find the ImageView in the list_item.xml and display the provided photo from Place object
        ImageView itemImageView = listItemview.findViewById(R.id.image);
        itemImageView.setImageResource(currentPlace.getImage_id());

        return listItemview;
    }
}
