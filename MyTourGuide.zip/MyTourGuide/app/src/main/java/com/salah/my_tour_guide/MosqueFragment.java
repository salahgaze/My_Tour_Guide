package com.salah.my_tour_guide;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MosqueFragment extends Fragment {

    private static final String ARG_id = "id";
    private static final String ARG_name = "name";

    // TODO: Rename and change types of parameters
    private int id;
    private String name;

    public MosqueFragment() {
        // Required empty public constructor
    }

    public static MosqueFragment newInstance(int param1, String param2) {
        MosqueFragment fragment = new MosqueFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_id, param1);
        args.putString(ARG_name, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            id = getArguments().getInt(ARG_id);
            name = getArguments().getString(ARG_name);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        ArrayList<touristic_places> places = new ArrayList<touristic_places>();
        // Add to an array new objects with the data
        places.add(new touristic_places(getString(R.string.Masjid_al_Haram), R.drawable.archaeological_museum_amaravati));
        places.add(new touristic_places(getString(R.string.Al_Masjid_an_Nabawi), R.drawable.archaeological_museum_amaravati));
        places.add(new touristic_places(getString(R.string.Grand_Jamia_Mosque), R.drawable.archaeological_museum_amaravati));
        places.add(new touristic_places(getString(R.string.Imam_Ali_Shrine), R.drawable.archaeological_museum_amaravati));

        // Inflate current View object in places_list.xml
        View rootView = inflater.inflate(R.layout.list, container, false);
        // Create PlaceAdapter object in current activity for data from places array
        touristic_places_adapter touristic_adapter = new touristic_places_adapter(getActivity(), places);
        // Create ListView object in places_list.xml and set the PlaceAdapter object to it
        ListView listView = rootView.findViewById(R.id.list);
        listView.setAdapter(touristic_adapter);
        // Return current View object with the data
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }
}