package com.salah.my_tour_guide;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class MuseumFragment extends Fragment {

    private static final String ARG_id = "id";
    private static final String ARG_name = "name";

    private int id;
    private String name;

    public MuseumFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static MuseumFragment newInstance(int param1, String param2) {
        MuseumFragment fragment = new MuseumFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_id, param1);
        args.putString(ARG_name, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            id = getArguments().getInt(ARG_id);
            name = getArguments().getString(ARG_name);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ArrayList<touristic_places> places = new ArrayList<touristic_places>();
        // Add to an array new objects with the data
        places.add(new touristic_places(getString(R.string.Archaeological_Museum_Amaravati), R.drawable.archaeological_museum_amaravati));
        places.add(new touristic_places(getString(R.string.Bhagwan_Mahavir_Government_Museum), R.drawable.archaeological_museum_amaravati));
        places.add(new touristic_places(getString(R.string.Victoria_Jubilee_Museum), R.drawable.archaeological_museum_amaravati));
        places.add(new touristic_places(getString(R.string.INS_Kursura_S20), R.drawable.archaeological_museum_amaravati));

        // Inflate current View object in places_list.xml
        View rootView = inflater.inflate(R.layout.list, container, false);
        // Create PlaceAdapter object in current activity for data from places array
        touristic_places_adapter touristic_adapter = new touristic_places_adapter(getActivity(), places);
        // Create ListView object in places_list.xml and set the PlaceAdapter object to it
        ListView listView = rootView.findViewById(R.id.list);
        listView.setAdapter(touristic_adapter);
        // Return current View object with the data
        return rootView;
    }
}