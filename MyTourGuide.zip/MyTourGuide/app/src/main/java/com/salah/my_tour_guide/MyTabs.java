package com.salah.my_tour_guide;

import androidx.fragment.app.Fragment;

class MyTabs {
    private Category category;
    private Fragment fragment;

    public MyTabs(Category tabname, Fragment fragment) {
        this.category = tabname;
        this.fragment = fragment;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category tabname) {
        this.category = tabname;
    }

    public Fragment getFragment() {
        return fragment;
    }

    public void setFragment(Fragment fragment) {
        this.fragment = fragment;
    }
}
